
import React, {Component, PureComponent } from "react";
import EventEmitter from "react-native-eventemitter"; 
import _ from 'lodash';
import InlineForm from './InlineForm';
import { Container,Alert,Nav,NavItem,FormGroup,Label,Table, Badge,Row,Col,Card,CardHeader,FormText,CardBlock,Button,Modal, ModalHeader, ModalBody, ModalFooter,Input, InputGroup, InputGroupAddon } from "reactstrap";
 

 class TableComponent extends  React.Component{
    constructor(props) {
        super(props);
     console.log(this.props.data);
       this.state={
           showInput:false,
           showIndex:'',
           values:{

           },
           tableData:props.data,
           currentPage: 1,
           todosPerPage: 3
          
       }
      this.editUser = this.editUser.bind(this);
      this.saveUser = this.saveUser.bind(this);
      this.cancelUser = this.cancelUser.bind(this);
      this.handleClick = this.handleClick.bind(this);
      this.getPrevious = this.getPrevious.bind(this);
      this.getNext = this.getNext.bind(this);
     
    }
    editUser(item,index){
        console.log(item);
        this.setState({
            showInput: true,
            showIndex:index,
            values:item
        })
    } 
    
    cancelUser(item){
         this.setState({
            showInput: false,
            showIndex:'',
            values:{}
        })

    }
    saveUser(item ,i){
        console.log(item);
        console.log(i);
        console.log(this.state.values);
         /*this.setState(state => ({
             data: state.data.map((row, j) => (j === i ? x : row))
         }));*/
         this.setState({
            showInput: false,
             showIndex:'',
        })
    }
    
    getPrevious(){
        if(this.state.currentPage>1){
          this.setState({
                 currentPage :this.state.currentPage -1
          })
      }
    }
    getNext(){
         const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(this.state.tableData.length / this.state.todosPerPage); i++) {
          pageNumbers.push(i);
        }
        let maxPageNumber = pageNumbers.length;
        if(maxPageNumber!= this.state.currentPage){
             this.setState({
                 currentPage :this.state.currentPage +1
          })
        }
    }


      handleClick(event) {
        this.setState({
          currentPage: Number(event.target.id)
        });
      }

     change = e => {
    const { name, value } = e.target;
    this.setState(state => ({
      values: {
        ...state.values,
        [name]: value
      }
    }));
  };

   render() {
        const { tableData, currentPage, todosPerPage } = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
        const currentTodos = tableData.slice(indexOfFirstTodo, indexOfLastTodo);
        const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(tableData.length / todosPerPage); i++) {
          pageNumbers.push(i);
        }

        const renderPageNumbers = pageNumbers.map(number => {
          return (

          <li   className={this.state.currentPage === number ? "page-item page-link active" : "page-item controls page-link"}  key={number}
              id={number}
            onClick={this.handleClick} >{number}</li>
          );
        });

    return (
         <div className="px-5 mt-5 table-responsive">
      <Table className="grid-table  table-bordered ">
        <thead>
          <tr>
              <th> </th>
              { this.props.header.map((item, index) => (
                   <th>{item.name}</th>
                ))}
          </tr>
        </thead>
        <tbody>
          { currentTodos.map((item, index) => (

          <tr key={index}>
           {this.state.showInput == true && this.state.showIndex === index ? <td ><span onClick={this.saveUser.bind(this,item,index)}>Save</span>{'  '}<span onClick={this.cancelUser.bind(this,item)}>Cancel</span> </td>:item.editStatus == 'Y' ? <td onClick={this.editUser.bind(this,item,index)}>Edit</td>  :<td></td>}
            {this.props.header.map((y, k) => (
             this.state.showIndex === index ? <td><Input  name={y.prop} onChange={this.change} value={this.state.values[y.prop]}/> </td> : <td key={`trc-${k}`}>{item[y.prop]}</td>

          ))}
             
            
          </tr>
          ))}
        </tbody>
      </Table>
       

            <nav aria-label="Page navigation" className="float-right">
              <ul className="pagination">
                <li className="page-item"  onClick={this.getPrevious}>
                  <a className="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                  </a>
                </li>
                {renderPageNumbers}
                <li className="page-item"   onClick={this.getNext}>
                  <a className="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                  </a>
                </li>
              </ul>
            </nav>
       
     </div>
   
    );     
}
}

export default TableComponent