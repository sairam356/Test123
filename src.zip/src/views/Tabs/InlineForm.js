
import React, {Component, PureComponent } from "react";
import EventEmitter from "react-native-eventemitter"; 
import _ from 'lodash';
 
import { Container,Alert,Nav,NavItem,FormGroup,Label,Table, Badge,Row,Col,Card,CardHeader,FormText,CardBlock,Button,Modal, ModalHeader, ModalBody, ModalFooter,Input, InputGroup, InputGroupAddon } from "reactstrap";
export default class InlineForm extends React.Component {
 constructor(props) {
    super(props);
    this.state = {
      values: {
        ...props.item
      },
     
    };
    console.log(this.props);
    console.log(this.state);
  }

   change = e => {
    const { name, value } = e.target;
    this.setState(state => ({
      values: {
        ...state.values,
        [name]: value
      }
    }));
  };

   render() {
    const { header, item, i ,name} = this.props;
    return [
    
    
          <Input
            name={this.props.name}
            onChange={this.change}
            value={this.state.values[this.props.name]}
          />
      
     
    ];
  }
}